import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';

import { Navbar } from '../../layouts/navbar/navbar';
import { Sidebar } from '../../layouts/sidebar/sidebar';

import { AnalyticsHeader } from './components/analytics-header/analytics-header';
import { AnalyticsSummaryCard } from './components/analytics-summary-card/analytics-summary-card';

import { ProcurementChart } from './components/procurement-chart/procurement-chart';
import { VendorChart } from './components/vendor-chart/vendor-chart';
import { RiskChart } from './components/risk-chart/risk-chart';
import { ContractChart } from './components/contract-chart/contract-chart';

@Component({
  selector: 'app-analytics',
  standalone: true,
  imports: [
    CommonModule,
    Navbar,
    Sidebar,
    AnalyticsHeader,
    AnalyticsSummaryCard,
    ProcurementChart,
    VendorChart,
    RiskChart,
    ContractChart
  ],
  templateUrl: './analytics.html',
  styleUrl: './analytics.css'
})
export class Analytics {

}