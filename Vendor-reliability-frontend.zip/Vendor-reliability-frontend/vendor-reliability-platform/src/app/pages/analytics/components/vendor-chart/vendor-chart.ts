import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';

import { MatCardModule } from '@angular/material/card';

import { ChartConfiguration } from 'chart.js';
import { BaseChartDirective } from 'ng2-charts';

@Component({
  selector: 'app-vendor-chart',
  standalone: true,
  imports: [
    CommonModule,
    MatCardModule,
    BaseChartDirective
  ],
  templateUrl: './vendor-chart.html',
  styleUrl: './vendor-chart.css'
})
export class VendorChart {

  barChartData: ChartConfiguration<'bar'>['data'] = {

    labels: [
      'ABC Tech',
      'Comfort',
      'Cisco',
      'Dell',
      'HP'
    ],

    datasets: [

      {

        label:'Performance Score',

        data:[95,88,91,84,90]

      }

    ]

  };

  barChartOptions: ChartConfiguration<'bar'>['options'] = {

    responsive:true,

    maintainAspectRatio:false

  };

}