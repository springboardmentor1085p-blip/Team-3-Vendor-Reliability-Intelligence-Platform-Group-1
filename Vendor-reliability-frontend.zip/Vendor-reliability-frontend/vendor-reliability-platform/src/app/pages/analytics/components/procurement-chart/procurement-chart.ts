import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';

import { MatCardModule } from '@angular/material/card';

import {
  ChartConfiguration
} from 'chart.js';

import { BaseChartDirective } from 'ng2-charts';

@Component({
  selector: 'app-procurement-chart',
  standalone: true,
  imports: [
    CommonModule,
    MatCardModule,
    BaseChartDirective
  ],
  templateUrl: './procurement-chart.html',
  styleUrl: './procurement-chart.css'
})
export class ProcurementChart {

  lineChartData: ChartConfiguration<'line'>['data'] = {

    labels: ['Jan','Feb','Mar','Apr','May','Jun'],

    datasets: [

      {

        label:'Procurement Cost',

        data:[12,18,15,22,28,30],

        tension:0.4,

        fill:false

      }

    ]

  };

  lineChartOptions: ChartConfiguration<'line'>['options'] = {

    responsive:true,

    maintainAspectRatio:false

  };

}