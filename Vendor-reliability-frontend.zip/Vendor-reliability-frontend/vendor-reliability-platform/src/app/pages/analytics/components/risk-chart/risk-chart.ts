import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';

import { MatCardModule } from '@angular/material/card';

import { ChartConfiguration } from 'chart.js';
import { BaseChartDirective } from 'ng2-charts';

@Component({
  selector: 'app-risk-chart',
  standalone: true,
  imports: [
    CommonModule,
    MatCardModule,
    BaseChartDirective
  ],
  templateUrl: './risk-chart.html',
  styleUrl: './risk-chart.css'
})
export class RiskChart {

  doughnutChartData: ChartConfiguration<'doughnut'>['data'] = {

    labels:[
      'Low',
      'Medium',
      'High'
    ],

    datasets:[

      {

        data:[65,25,10]

      }

    ]

  };

  doughnutChartOptions: ChartConfiguration<'doughnut'>['options'] = {

    responsive:true,

    maintainAspectRatio:false

  };

}