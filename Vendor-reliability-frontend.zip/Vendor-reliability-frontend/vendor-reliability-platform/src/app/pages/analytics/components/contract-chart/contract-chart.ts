import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';

import { MatCardModule } from '@angular/material/card';

import { ChartConfiguration } from 'chart.js';
import { BaseChartDirective } from 'ng2-charts';

@Component({
  selector: 'app-contract-chart',
  standalone: true,
  imports: [
    CommonModule,
    MatCardModule,
    BaseChartDirective
  ],
  templateUrl: './contract-chart.html',
  styleUrl: './contract-chart.css'
})
export class ContractChart {

  pieChartData: ChartConfiguration<'pie'>['data'] = {

    labels:[
      'Active',
      'Expiring',
      'Expired'
    ],

    datasets:[

      {

        data:[60,25,15]

      }

    ]

  };

  pieChartOptions: ChartConfiguration<'pie'>['options'] = {

    responsive:true,

    maintainAspectRatio:false

  };

}