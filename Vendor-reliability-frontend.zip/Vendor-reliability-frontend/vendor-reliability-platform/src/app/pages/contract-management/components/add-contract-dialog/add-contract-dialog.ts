import { Component, inject } from '@angular/core';
import { FormBuilder, ReactiveFormsModule, Validators } from '@angular/forms';

import { MatDialogModule, MatDialogRef } from '@angular/material/dialog';
import { MatButtonModule } from '@angular/material/button';
import { MatInputModule } from '@angular/material/input';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatSelectModule } from '@angular/material/select';

@Component({
  selector: 'app-add-contract-dialog',
  standalone: true,
  imports: [
    ReactiveFormsModule,
    MatDialogModule,
    MatButtonModule,
    MatInputModule,
    MatFormFieldModule,
    MatSelectModule
  ],
  templateUrl: './add-contract-dialog.html',
  styleUrl: './add-contract-dialog.css'
})
export class AddContractDialog {

  private fb = inject(FormBuilder);

  private dialogRef = inject(MatDialogRef<AddContractDialog>);

  contractForm = this.fb.group({

    contractId:['', Validators.required],

    vendor:['', Validators.required],

    startDate:['', Validators.required],

    endDate:['', Validators.required],

    contractValue:[0, Validators.required],

    status:['Active', Validators.required],

    description:['']

  });

  save(){

    if(this.contractForm.invalid){

      this.contractForm.markAllAsTouched();

      return;

    }

    this.dialogRef.close(this.contractForm.value);

  }

  cancel(){

    this.dialogRef.close();

  }

}