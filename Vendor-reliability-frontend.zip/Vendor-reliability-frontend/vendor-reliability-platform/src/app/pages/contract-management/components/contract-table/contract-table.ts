import { Component } from '@angular/core';
import { DecimalPipe } from '@angular/common';

import { MatTableModule } from '@angular/material/table';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatPaginatorModule } from '@angular/material/paginator';
import { MatChipsModule } from '@angular/material/chips';
import { MatDialog } from '@angular/material/dialog';
import { ViewContractDialog } from '../view-contract-dialog/view-contract-dialog';

export interface Contract {

  contractId: string;

  vendor: string;

  startDate: string;

  endDate: string;

  contractValue: number;

  status: string;

}

@Component({
  selector: 'app-contract-table',
  standalone: true,
  imports: [
    MatTableModule,
    MatButtonModule,
    MatIconModule,
    MatPaginatorModule,
    MatChipsModule,
    DecimalPipe
  ],
  templateUrl: './contract-table.html',
  styleUrl: './contract-table.css'
})
export class ContractTable {

  displayedColumns = [
    'contractId',
    'vendor',
    'startDate',
    'endDate',
    'contractValue',
    'status',
    'actions'
  ];

  dataSource: Contract[] = [

    {
      contractId: 'CT-1001',
      vendor: 'ABC Technologies',
      startDate: '01 Jul 2026',
      endDate: '30 Jun 2027',
      contractValue: 2500000,
      status: 'Active'
    },

    {
      contractId: 'CT-1002',
      vendor: 'Comfort Furniture',
      startDate: '15 Jan 2026',
      endDate: '15 Aug 2026',
      contractValue: 850000,
      status: 'Expiring'
    },

    {
      contractId: 'CT-1003',
      vendor: 'Cisco Systems',
      startDate: '01 Jan 2025',
      endDate: '31 Dec 2025',
      contractValue: 1800000,
      status: 'Expired'
    }

  ];
constructor(private dialog: MatDialog) {}
  view(contract: Contract): void {

  this.dialog.open(ViewContractDialog, {
    width: '600px',
    data: contract
  });

}
}