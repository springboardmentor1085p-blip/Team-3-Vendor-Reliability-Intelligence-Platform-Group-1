import { Component } from '@angular/core';
import { MatButtonModule } from '@angular/material/button';
import { MatDialog, MatDialogModule } from '@angular/material/dialog';

import { AddContractDialog } from '../add-contract-dialog/add-contract-dialog';

@Component({
  selector:'app-contract-header',
  standalone:true,
  imports:[
    MatButtonModule,
    MatDialogModule
  ],
  templateUrl:'./contract-header.html',
  styleUrl:'./contract-header.css'
})
export class ContractHeader{

  constructor(private dialog:MatDialog){}

  newContract(){

    this.dialog.open(AddContractDialog,{

      width:'700px',

      maxHeight:'90vh',

      autoFocus:false

    });

  }

}