import { Component } from '@angular/core';

import { Navbar } from '../../layouts/navbar/navbar';
import { Sidebar } from '../../layouts/sidebar/sidebar';
import { ContractHeader } from './components/contract-header/contract-header';
import { ContractSummaryCard } from './components/contract-summary-card/contract-summary-card';
import { ContractToolbar } from './components/contract-toolbar/contract-toolbar';
import { ContractTable } from './components/contract-table/contract-table';

@Component({
  selector:'app-contract-management',
  standalone:true,
  imports:[
    Navbar,
    Sidebar,
    ContractHeader,
    ContractSummaryCard,
    ContractToolbar,
    ContractTable
  ],
  templateUrl:'./contract-management.html',
  styleUrl:'./contract-management.css'
})
export class ContractManagement{

}