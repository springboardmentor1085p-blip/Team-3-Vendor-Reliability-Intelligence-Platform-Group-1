import { Component } from '@angular/core';
import { MatButtonModule } from '@angular/material/button';
import { MatDialog, MatDialogModule } from '@angular/material/dialog';

import { AddPurchaseOrderDialog } from '../add-purchase-order-dialog/add-purchase-order-dialog';

@Component({
  selector: 'app-purchase-header',
  standalone: true,
 imports:[
MatButtonModule,
MatDialogModule
],
templateUrl:'./purchase-header.html',
styleUrl:'./purchase-header.css'
})
export class PurchaseHeader{

constructor(private dialog:MatDialog){}

newPurchaseOrder(){

this.dialog.open(AddPurchaseOrderDialog,{

width:'700px',
maxHeight:'90vh',
autoFocus:false

});

}

}