import { Component, inject } from '@angular/core';
import { FormBuilder, ReactiveFormsModule, Validators } from '@angular/forms';

import { MatDialogModule, MatDialogRef } from '@angular/material/dialog';
import { MatButtonModule } from '@angular/material/button';
import { MatInputModule } from '@angular/material/input';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatSelectModule } from '@angular/material/select';

@Component({
  selector: 'app-add-purchase-order-dialog',
  standalone: true,
  imports: [
    ReactiveFormsModule,
    MatDialogModule,
    MatButtonModule,
    MatInputModule,
    MatFormFieldModule,
    MatSelectModule
  ],
  templateUrl: './add-purchase-order-dialog.html',
  styleUrl: './add-purchase-order-dialog.css'
})
export class AddPurchaseOrderDialog {

  private fb = inject(FormBuilder);

  private dialogRef = inject(MatDialogRef<AddPurchaseOrderDialog>);

  purchaseForm = this.fb.group({

    poNumber:['', Validators.required],

    supplier:['', Validators.required],

    item:['', Validators.required],

    quantity:[1, Validators.required],

    unitPrice:[0, Validators.required],

    totalAmount:[0, Validators.required],

    orderDate:['', Validators.required],

    deliveryDate:['', Validators.required],

    status:['Pending', Validators.required],

    remarks:['']

  });

  save(){

    if(this.purchaseForm.invalid){

      this.purchaseForm.markAllAsTouched();

      return;

    }

    this.dialogRef.close(this.purchaseForm.value);

  }

  cancel(){

    this.dialogRef.close();

  }

}