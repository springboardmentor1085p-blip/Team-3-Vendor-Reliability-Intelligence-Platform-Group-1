import { Component } from '@angular/core';

import { DecimalPipe } from '@angular/common';

import { MatTableModule } from '@angular/material/table';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatPaginatorModule } from '@angular/material/paginator';
import { MatChipsModule } from '@angular/material/chips';
import { MatDialog } from '@angular/material/dialog';
import { ViewPurchaseOrderDialog } from '../view-purchase-order-dialog/view-purchase-order-dialog';

export interface PurchaseOrder {

  poNumber:string;

  supplier:string;

  item:string;

  quantity:number;

  totalAmount:number;

  orderDate:string;

  deliveryDate:string;

  status:string;

}

@Component({
  selector:'app-purchase-table',
  standalone:true,
  imports:[
    MatTableModule,
    MatButtonModule,
    MatIconModule,
    MatPaginatorModule,
    MatChipsModule,
    DecimalPipe
  ],
  templateUrl:'./purchase-table.html',
  styleUrl:'./purchase-table.css'
})

export class PurchaseTable{

  displayedColumns=[
    'poNumber',
    'supplier',
    'item',
    'quantity',
    'totalAmount',
    'orderDate',
    'deliveryDate',
    'status',
    'actions'
  ];

  dataSource:PurchaseOrder[]=[

    {
      poNumber:'PO-1001',
      supplier:'ABC Technologies',
      item:'Dell Latitude Laptop',
      quantity:20,
      totalAmount:1200000,
      orderDate:'20 Jul 2026',
      deliveryDate:'30 Jul 2026',
      status:'Approved'
    },

    {
      poNumber:'PO-1002',
      supplier:'Comfort Furniture',
      item:'Office Chairs',
      quantity:40,
      totalAmount:450000,
      orderDate:'18 Jul 2026',
      deliveryDate:'05 Aug 2026',
      status:'Pending'
    },

    {
      poNumber:'PO-1003',
      supplier:'Cisco Systems',
      item:'Network Switch',
      quantity:5,
      totalAmount:600000,
      orderDate:'15 Jul 2026',
      deliveryDate:'28 Jul 2026',
      status:'Completed'
    }

  ];
constructor(private dialog: MatDialog) {}
 view(order: PurchaseOrder): void {

  this.dialog.open(ViewPurchaseOrderDialog, {
    width: '600px',
    data: order
  });

}
  

}