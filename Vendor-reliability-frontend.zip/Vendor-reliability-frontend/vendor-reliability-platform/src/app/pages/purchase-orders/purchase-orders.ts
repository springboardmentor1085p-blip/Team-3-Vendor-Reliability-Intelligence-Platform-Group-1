import { Component } from '@angular/core';
import { Navbar } from '../../layouts/navbar/navbar';
import { Sidebar } from '../../layouts/sidebar/sidebar';
import { PurchaseHeader } from './components/purchase-header/purchase-header';
import { PurchaseSummaryCard } from './components/purchase-summary-card/purchase-summary-card';
import { PurchaseToolbar } from './components/purchase-toolbar/purchase-toolbar';
import { PurchaseTable } from './components/purchase-table/purchase-table';


@Component({
  selector: 'app-purchase-orders',
  standalone: true,
  imports: [
    Navbar,
    Sidebar,
    PurchaseHeader,
    PurchaseSummaryCard,
    PurchaseToolbar,
    PurchaseTable
  ],
  templateUrl: './purchase-orders.html',
  styleUrl: './purchase-orders.css'
})
export class PurchaseOrders {

}