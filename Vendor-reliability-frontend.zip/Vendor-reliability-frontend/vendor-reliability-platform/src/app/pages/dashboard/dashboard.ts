import { Component } from '@angular/core';

import { Navbar } from '../../layouts/navbar/navbar';
import { Sidebar } from '../../layouts/sidebar/sidebar';

import { DashboardHeader } from './components/dashboard-header/dashboard-header';
import { KpiCard } from './components/kpi-card/kpi-card';
import { ChartCard } from './components/chart-card/chart-card';
import { RecentOrders } from './components/recent-orders/recent-orders';
import { RiskAlerts } from './components/risk-alerts/risk-alerts';
import { RecentActivity } from './components/recent-activity/recent-activity';

import { MatExpansionModule } from '@angular/material/expansion';

import { ChartConfiguration } from 'chart.js';


@Component({
  selector: 'app-dashboard',

  standalone: true,

  imports: [
    Navbar,
    Sidebar,
    DashboardHeader,
    KpiCard,
    ChartCard,
    RecentOrders,
    RiskAlerts,
    RecentActivity,
    MatExpansionModule
  ],

  templateUrl: './dashboard.html',

  styleUrl: './dashboard.css'
})

export class Dashboard {


  // =================================
  // Vendor Performance Bar Chart
  // =================================

  vendorPerformanceData: ChartConfiguration['data'] = {

    labels: [
      'ABC Technologies',
      'Cisco Systems',
      'Comfort Furniture',
      'Global Logistics'
    ],

    datasets: [
      {
        label: 'Performance Score',

        data: [
          92,
          87,
          78,
          72
        ]
      }
    ]

  };


  // =================================
  // Procurement Analytics Line Chart
  // =================================

  procurementAnalyticsData: ChartConfiguration['data'] = {

    labels: [
      'Jan',
      'Feb',
      'Mar',
      'Apr',
      'May',
      'Jun'
    ],

    datasets: [
      {
        label: 'Procurement Spend',

        data: [
          420000,
          510000,
          480000,
          630000,
          710000,
          670000
        ],

        tension: 0.4,

        fill: false
      }
    ]

  };

}