import { Component } from '@angular/core';
import { MatCardModule } from '@angular/material/card';
import { MatListModule } from '@angular/material/list';
import { MatIconModule } from '@angular/material/icon';

@Component({
  selector: 'app-recent-activity',
  standalone: true,
  imports: [
    MatCardModule,
    MatListModule,
    MatIconModule
  ],
  templateUrl: './recent-activity.html',
  styleUrl: './recent-activity.css'
})
export class RecentActivity {

  activities = [

    {
      icon: 'person_add',
      color: 'green',
      text: 'Vendor ABC Ltd added successfully'
    },

    {
      icon: 'shopping_cart_checkout',
      color: 'blue',
      text: 'Purchase Order PO003 approved'
    },

    {
      icon: 'description',
      color: 'orange',
      text: 'Contract renewed with XYZ Pvt Ltd'
    },

    {
      icon: 'warning',
      color: 'red',
      text: 'Vendor DEF marked as High Risk'
    }

  ];

}