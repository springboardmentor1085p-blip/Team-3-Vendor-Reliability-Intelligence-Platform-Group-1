import { Component } from '@angular/core';
import { MatCardModule } from '@angular/material/card';
import { MatTableModule } from '@angular/material/table';

interface Risk {

  vendor: string;
  risk: string;

}

@Component({
  selector: 'app-risk-alerts',
  standalone: true,
  imports: [MatCardModule, MatTableModule],
  templateUrl: './risk-alerts.html',
  styleUrl: './risk-alerts.css'
})
export class RiskAlerts {

  displayedColumns: string[] = ['vendor', 'risk'];

  dataSource: Risk[] = [
    { vendor: 'ABC Ltd', risk: '🔴 High' },
    { vendor: 'XYZ Pvt Ltd', risk: '🟡 Medium' },
    { vendor: 'PQR Industries', risk: '🟢 Low' }
  ];

}