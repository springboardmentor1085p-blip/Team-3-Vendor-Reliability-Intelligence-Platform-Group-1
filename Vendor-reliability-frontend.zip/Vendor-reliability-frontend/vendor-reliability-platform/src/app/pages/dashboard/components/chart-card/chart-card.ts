import { Component, Input } from '@angular/core';
import { MatCardModule } from '@angular/material/card';
import { BaseChartDirective } from 'ng2-charts';
import { ChartConfiguration, ChartType } from 'chart.js';

@Component({
  selector: 'app-chart-card',
  standalone: true,
  imports: [
    MatCardModule,
    BaseChartDirective
  ],
  templateUrl: './chart-card.html',
  styleUrl: './chart-card.css'
})
export class ChartCard {

  @Input() title = '';

  @Input() chartType: ChartType = 'bar';

  @Input() chartData: ChartConfiguration['data'] = {
    labels: [],
    datasets: []
  };

  chartOptions: ChartConfiguration['options'] = {
    responsive: true,
    maintainAspectRatio: false,

    plugins: {
      legend: {
        display: true,
        position: 'top'
      }
    },

    scales: {
      y: {
        beginAtZero: true
      }
    }
  };

}