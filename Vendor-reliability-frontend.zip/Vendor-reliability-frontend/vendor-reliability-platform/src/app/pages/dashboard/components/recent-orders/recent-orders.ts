import { Component } from '@angular/core';
import { MatTableModule } from '@angular/material/table';
import { MatCardModule } from '@angular/material/card';

interface PurchaseOrder {

  poId:string;

  vendor:string;

  amount:string;

  status:string;

}

@Component({
  selector:'app-recent-orders',
  standalone:true,
  imports:[MatTableModule,MatCardModule],
  templateUrl:'./recent-orders.html',
  styleUrl:'./recent-orders.css'
})

export class RecentOrders{

  displayedColumns:string[]=[
    'poId',
    'vendor',
    'amount',
    'status'
  ];

  dataSource:PurchaseOrder[]=[
    {
      poId:'PO001',
      vendor:'ABC Ltd',
      amount:'₹50,000',
      status:'Approved'
    },
    {
      poId:'PO002',
      vendor:'XYZ Ltd',
      amount:'₹25,000',
      status:'Pending'
    },
    {
      poId:'PO003',
      vendor:'Delta Ltd',
      amount:'₹90,000',
      status:'Delivered'
    }
  ];

}