import { Component } from '@angular/core';
import { ReactiveFormsModule, FormBuilder } from '@angular/forms';

import { MatCardModule } from '@angular/material/card';
import { MatSlideToggleModule } from '@angular/material/slide-toggle';

@Component({
  selector: 'app-notification-settings',
  standalone: true,
  imports: [
    ReactiveFormsModule,
    MatCardModule,
    MatSlideToggleModule
  ],
  templateUrl: './notification-settings.html',
  styleUrl: './notification-settings.css'
})
export class NotificationSettings {

  notificationForm;

  constructor(private fb: FormBuilder){

    this.notificationForm = this.fb.group({

      email:[true],
      sms:[false],
      vendorAlerts:[true],
      contractAlerts:[true]

    });

  }

}