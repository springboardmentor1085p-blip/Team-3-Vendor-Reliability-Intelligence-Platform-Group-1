import { Component } from '@angular/core';
import { FormBuilder, ReactiveFormsModule } from '@angular/forms';

import { MatCardModule } from '@angular/material/card';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatSelectModule } from '@angular/material/select';

@Component({
  selector: 'app-preference-settings',
  standalone: true,
  imports: [
    ReactiveFormsModule,
    MatCardModule,
    MatFormFieldModule,
    MatSelectModule
  ],
  templateUrl: './preference-settings.html',
  styleUrl: './preference-settings.css'
})
export class PreferenceSettings {

  preferenceForm;

  constructor(private fb: FormBuilder){

    this.preferenceForm = this.fb.group({

      language:['English'],
      theme:['Light'],
      timezone:['Asia/Kolkata'],
      currency:['INR']

    });

  }

}