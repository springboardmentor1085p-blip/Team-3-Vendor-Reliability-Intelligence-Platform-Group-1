import { Component } from '@angular/core';
import { ReactiveFormsModule, FormBuilder } from '@angular/forms';

import { MatCardModule } from '@angular/material/card';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatDividerModule } from '@angular/material/divider';
import { MatIconModule } from '@angular/material/icon';

@Component({
  selector: 'app-company-settings',
  standalone: true,
  imports: [
    ReactiveFormsModule,
    MatCardModule,
    MatFormFieldModule,
    MatInputModule,
    MatDividerModule,
    MatIconModule
  ],
  templateUrl: './company-settings.html',
  styleUrl: './company-settings.css'
})
export class CompanySettings {

  companyForm;

  constructor(private fb: FormBuilder){

    this.companyForm = this.fb.group({

      companyName:['Vendor Reliability Pvt Ltd'],
      email:['admin@vendorplatform.com'],
      phone:['+91 9876543210'],
      address:['Hyderabad, Telangana']

    });

  }

}