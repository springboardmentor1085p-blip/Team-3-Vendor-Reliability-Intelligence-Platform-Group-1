import { Component } from '@angular/core';
import { FormBuilder, ReactiveFormsModule } from '@angular/forms';

import { MatCardModule } from '@angular/material/card';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSlideToggleModule } from '@angular/material/slide-toggle';

@Component({
  selector: 'app-security-settings',
  standalone: true,
 imports: [
    ReactiveFormsModule,
    MatCardModule,
    MatFormFieldModule,
    MatInputModule,
    MatSlideToggleModule
  ],
  templateUrl: './security-settings.html',
  styleUrl: './security-settings.css'
})
export class SecuritySettings {

  securityForm;

  constructor(private fb: FormBuilder){

    this.securityForm = this.fb.group({

      currentPassword:[''],
      newPassword:[''],
      confirmPassword:[''],
      twoFactor:[false]

    });

  }

}