import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';

import { Navbar } from '../../layouts/navbar/navbar';
import { Sidebar } from '../../layouts/sidebar/sidebar';
import { SettingsHeader } from './components/settings-header/settings-header';
import { CompanySettings } from './components/company-settings/company-settings';
import { NotificationSettings } from './components/notification-settings/notification-settings';
import { PreferenceSettings } from './components/preference-settings/preference-settings';
import { SecuritySettings } from './components/security-settings/security-settings';

@Component({
  selector: 'app-settings',
  standalone: true,
  imports: [
    CommonModule,
    Navbar,
    Sidebar,
    SettingsHeader,
    CompanySettings,
    NotificationSettings,
    PreferenceSettings,
    SecuritySettings
  ],
  templateUrl: './settings.html',
  styleUrl: './settings.css'
})
export class Settings {}