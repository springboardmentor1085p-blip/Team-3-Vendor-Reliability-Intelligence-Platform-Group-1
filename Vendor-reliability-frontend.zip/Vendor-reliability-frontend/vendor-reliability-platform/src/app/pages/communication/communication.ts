import { Component } from '@angular/core';
import { Navbar } from '../../layouts/navbar/navbar';
import { Sidebar } from '../../layouts/sidebar/sidebar';
import { CommunicationHeader } from './components/communication-header/communication-header';
import { CommunicationSummaryCard } from './components/communication-summary-card/communication-summary-card';
import { CommunicationToolbar } from './components/communication-toolbar/communication-toolbar';
import { CommunicationTable } from './components/communication-table/communication-table';

@Component({
  selector: 'app-communication',
  standalone: true,
  imports: [
    Navbar,
    Sidebar,
    CommunicationHeader,
    CommunicationSummaryCard,
    CommunicationToolbar,
    CommunicationTable
  ],
  templateUrl: './communication.html',
  styleUrl: './communication.css'
})
export class Communication {

}