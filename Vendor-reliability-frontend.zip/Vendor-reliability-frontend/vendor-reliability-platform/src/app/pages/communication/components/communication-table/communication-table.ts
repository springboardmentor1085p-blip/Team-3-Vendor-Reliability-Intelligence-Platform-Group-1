import { Component, inject } from '@angular/core';

import { MatTableModule } from '@angular/material/table';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatChipsModule } from '@angular/material/chips';
import { MatPaginatorModule } from '@angular/material/paginator';
import { MatDialog } from '@angular/material/dialog';
import { MatMenuModule } from '@angular/material/menu';

import { ViewMessageDialog } from '../view-message-dialog/view-message-dialog';

interface Message {

  vendor:string;

  subject:string;

  type:string;

  date:string;

  status:string;

  attachment:string;

}

@Component({
  selector:'app-communication-table',
  standalone:true,
  imports:[
    MatTableModule,
    MatButtonModule,
    MatIconModule,
    MatChipsModule,
    MatPaginatorModule,
    MatMenuModule
  ],
  templateUrl:'./communication-table.html',
  styleUrl:'./communication-table.css'
})
export class CommunicationTable {

  private dialog = inject(MatDialog);

  displayedColumns = [
    'vendor',
    'subject',
    'type',
    'date',
    'status',
    'attachment',
    'actions'
  ];

  dataSource: Message[] = [

    {
      vendor:'ABC Technologies',
      subject:'Purchase Order Approval',
      type:'Email',
      date:'20 Jul 2026',
      status:'Read',
      attachment:'PO_1045.pdf'
    },

    {
      vendor:'XYZ Hardware',
      subject:'Delivery Delay',
      type:'Discussion',
      date:'19 Jul 2026',
      status:'Unread',
      attachment:'Delay_Report.pdf'
    },

    {
      vendor:'Global Logistics',
      subject:'Invoice Submission',
      type:'Message',
      date:'18 Jul 2026',
      status:'Read',
      attachment:'Invoice.pdf'
    }

  ];

 viewCommunication(communication: Message): void {

  this.dialog.open(ViewMessageDialog, {
    width: '600px',
    data: communication
  });

}

}