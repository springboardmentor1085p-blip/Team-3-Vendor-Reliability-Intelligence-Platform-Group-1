import { Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, ReactiveFormsModule, Validators } from '@angular/forms';

import { MatDialogModule, MatDialogRef } from '@angular/material/dialog';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';

@Component({
  selector: 'app-compose-message-dialog',
  standalone: true,
  imports: [
    CommonModule,
    ReactiveFormsModule,
    MatDialogModule,
    MatFormFieldModule,
    MatInputModule,
    MatSelectModule,
    MatCheckboxModule,
    MatButtonModule,
    MatIconModule
  ],
  templateUrl: './compose-message-dialog.html',
  styleUrl: './compose-message-dialog.css'
})
export class ComposeMessageDialog {

  private fb = inject(FormBuilder);

  private dialogRef = inject(MatDialogRef<ComposeMessageDialog>);

  messageForm = this.fb.group({

    vendor: ['', Validators.required],

    subject: ['', Validators.required],

    type: ['Email', Validators.required],

    message: ['', Validators.required],

    emailNotification: [true]

  });

  selectedFile: File | null = null;

  onFileSelected(event: Event) {

    const input = event.target as HTMLInputElement;

    if (input.files && input.files.length > 0) {

      this.selectedFile = input.files[0];

    }

  }

  sendMessage() {

    if (this.messageForm.valid) {

      this.dialogRef.close({

        ...this.messageForm.value,

        attachment: this.selectedFile?.name

      });

    }

  }

}