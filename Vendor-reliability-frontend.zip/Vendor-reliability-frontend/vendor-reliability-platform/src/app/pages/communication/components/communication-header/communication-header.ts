import { Component } from '@angular/core';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatDialog } from '@angular/material/dialog';
import { inject } from '@angular/core';
import { ComposeMessageDialog } from '../compose-message-dialog/compose-message-dialog';

@Component({
  selector: 'app-communication-header',
  standalone: true,
  imports: [
    MatButtonModule,
    MatIconModule
  ],
  templateUrl: './communication-header.html',
  styleUrl: './communication-header.css'
})
export class CommunicationHeader {

  private dialog = inject(MatDialog);

composeMessage(){

  this.dialog.open(ComposeMessageDialog,{
    width:'700px'
  });

}

}

