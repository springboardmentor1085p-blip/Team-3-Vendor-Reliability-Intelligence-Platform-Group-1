import { Component, inject } from '@angular/core';
import { MatTableModule } from '@angular/material/table';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatChipsModule } from '@angular/material/chips';
import { MatPaginatorModule } from '@angular/material/paginator';
import { ViewVendorDialog } from '../view-vendor-dialog/view-vendor-dialog';
import { MatMenuModule } from '@angular/material/menu';
import { MatDialog } from '@angular/material/dialog';
import { EditVendorDialog } from '../edit-vendor-dialog/edit-vendor-dialog';
import { DeleteVendorDialog } from '../delete-vendor-dialog/delete-vendor-dialog';

interface Vendor {
  name: string;
  category: string;
  vendorType: string;
  contact: string;
  email: string;
  status: string;
  rating: number;
  risk: string;
}

@Component({
  selector: 'app-vendor-table',
  standalone: true,
  imports: [
    MatTableModule,
    MatButtonModule,
    MatIconModule,
    MatChipsModule,
    MatPaginatorModule,
    MatMenuModule
    
  ],
  templateUrl: './vendor-table.html',
  styleUrl: './vendor-table.css'
})
export class VendorTable {

  displayedColumns: string[] = [
    'name',
    'category',
    'vendorType',
    'contact',
    'email',
    'status',
    'rating',
    'risk',
    'actions'
  ];

  dataSource: Vendor[] = [
    {
      name: 'ABC Technologies',
      category: 'IT',
      vendorType: 'Manufacturer',
      contact: '9876543210',
      email: 'abc@gmail.com',
      status: 'Active',
      rating: 4.8,
      risk: 'Low'
    },
    {
      name: 'XYZ Hardware',
      category: 'Hardware',
      vendorType: 'Distributor',
      contact: '9876501234',
      email: 'xyz@gmail.com',
      status: 'Active',
      rating: 4.5,
      risk: 'Medium'
    },
    {
      name: 'Global Logistics',
      category: 'Logistics',
      vendorType: 'Service Provider',
      contact: '9988776655',
      email: 'global@gmail.com',
      status: 'Inactive',
      rating: 3.9,
      risk: 'High'
    }
  ];

  private dialog = inject(MatDialog)
viewVendor(vendor: Vendor): void {

  this.dialog.open(ViewVendorDialog,{

    width:'550px',

    data:vendor

  });

}

editVendor(vendor: Vendor): void {

  const dialogRef = this.dialog.open(EditVendorDialog,{

    width:'500px',

    data:{...vendor}

  });

  dialogRef.afterClosed().subscribe(result=>{

    if(result){

      const index=this.dataSource.findIndex(

        item=>item.email===vendor.email

      );

      if(index!==-1){

        this.dataSource[index]={

          ...this.dataSource[index],

          ...result

        };

        this.dataSource=[...this.dataSource];

      }

    }

  });

}

deleteVendor(vendor: Vendor): void {

  const dialogRef=this.dialog.open(DeleteVendorDialog,{

    width:'420px',

    data:vendor

  });

  dialogRef.afterClosed().subscribe(result=>{

    if(result){

      this.dataSource=this.dataSource.filter(

        item=>item.email!==vendor.email

      );

    }

  });

}
}
