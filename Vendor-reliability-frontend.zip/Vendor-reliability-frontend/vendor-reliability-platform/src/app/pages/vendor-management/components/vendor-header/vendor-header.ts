import { Component } from '@angular/core';
import { MatDialog, MatDialogModule } from '@angular/material/dialog';
import { MatButtonModule } from '@angular/material/button';
import { AddVendorDialog } from '../add-vendor-dialog/add-vendor-dialog';

@Component({
  selector: 'app-vendor-header',
  standalone: true,
  imports: [MatDialogModule, MatButtonModule],
  templateUrl: './vendor-header.html',
  styleUrl: './vendor-header.css'
})
export class VendorHeader {

  // Inject the MatDialog service here
  constructor(private dialog: MatDialog) {}

 openDialog() {

  const dialogRef = this.dialog.open(AddVendorDialog, {

    width: '600px'

  });

  dialogRef.afterClosed().subscribe(result => {

    if(result){

      console.log('Vendor Saved:', result);

    }

  });

}

}