import { Component } from '@angular/core';
import { Navbar } from '../../layouts/navbar/navbar';
import { Sidebar } from '../../layouts/sidebar/sidebar';
import { VendorHeader } from './components/vendor-header/vendor-header';
import { VendorToolbar } from './components/vendor-toolbar/vendor-toolbar';
import { VendorTable } from './components/vendor-table/vendor-table';
import { VendorSummaryCard } from './components/vendor-summary-card/vendor-summary-card';


@Component({
  selector: 'app-vendor-management',
  standalone: true,
  imports: [
    Navbar,
    Sidebar,
    VendorHeader,
    VendorToolbar,
    VendorTable,
    VendorSummaryCard,
  ],
  templateUrl: './vendor-management.html',
  styleUrl: './vendor-management.css'
})
export class VendorManagement {

}