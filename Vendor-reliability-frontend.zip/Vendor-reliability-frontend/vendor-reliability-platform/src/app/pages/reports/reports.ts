import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';

import { Navbar } from '../../layouts/navbar/navbar';
import { Sidebar } from '../../layouts/sidebar/sidebar';

import { ReportsHeader } from './components/reports-header/reports-header';
import { ReportsToolbar } from './components/reports-toolbar/reports-toolbar';
import { ReportsTable } from './components/reports-table/reports-table';
import { MatDialog, MatDialogModule } from '@angular/material/dialog';

import {
  GenerateReportDialog
} from './components/generate-report-dialog/generate-report-dialog';

@Component({
  selector: 'app-reports',
  standalone: true,
  imports: [
    CommonModule,
    Navbar,
    Sidebar,
    ReportsHeader,
    ReportsToolbar,
    ReportsTable,
    MatDialogModule
  ],
  templateUrl: './reports.html',
  styleUrl: './reports.css'
})

export class Reports {

  constructor(private dialog: MatDialog) {}

  openGenerateReport(): void {

    const dialogRef = this.dialog.open(
      GenerateReportDialog,
      {
        width: '500px'
      }
    );

    dialogRef.afterClosed().subscribe(result => {

      if (result) {

        console.log('Generated Report:', result);

        // Next step:
        // Add this generated report to ReportsTable

      }

    });

  }

}