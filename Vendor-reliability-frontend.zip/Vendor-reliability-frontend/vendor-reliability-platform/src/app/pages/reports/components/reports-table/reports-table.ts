import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';

import { MatTableModule } from '@angular/material/table';
import { MatPaginatorModule } from '@angular/material/paginator';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { inject } from '@angular/core';

import { MatDialog } from '@angular/material/dialog';

import { ViewReportDialog } from '../view-report-dialog/view-report-dialog';

import { MatMenuModule } from '@angular/material/menu';

interface Report{

  reportName:string;

  category:string;

  generatedDate:string;

  status:string;

}

@Component({
  selector:'app-reports-table',
  standalone:true,
  imports:[
    CommonModule,
    MatTableModule,
    MatPaginatorModule,
    MatButtonModule,
    MatIconModule,
    MatMenuModule
  ],
  templateUrl:'./reports-table.html',
  styleUrl:'./reports-table.css'
})
export class ReportsTable{

  displayedColumns=[
    'reportName',
    'category',
    'generatedDate',
    'status',
    'actions'
  ];

  dataSource:Report[]=[

    {
      reportName:'Vendor Performance Report',
      category:'Vendor',
      generatedDate:'20 Jul 2026',
      status:'Generated'
    },

    {
      reportName:'Monthly Procurement Report',
      category:'Procurement',
      generatedDate:'18 Jul 2026',
      status:'Generated'
    },

    {
      reportName:'Contract Expiry Report',
      category:'Contract',
      generatedDate:'15 Jul 2026',
      status:'Pending'
    }

  ];
private dialog = inject(MatDialog);
viewReport(report: Report): void {

  this.dialog.open(ViewReportDialog, {
    width: '600px',
    data: report
  });

}

downloadReport(report: Report): void {
  console.log('Download Report:', report);
}

}