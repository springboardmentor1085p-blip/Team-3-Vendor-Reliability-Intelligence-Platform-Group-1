import { Component } from '@angular/core';
import { MatButtonModule } from '@angular/material/button';
import { MatDialog, MatDialogModule } from '@angular/material/dialog';

import { AddProcurementDialog } from '../add-procurement-dialog/add-procurement-dialog';

@Component({
  selector: 'app-procurement-header',
  standalone: true,
  imports: [
    MatButtonModule,
    MatDialogModule
  ],
  templateUrl: './procurement-header.html',
  styleUrl: './procurement-header.css'
})
export class ProcurementHeader {

  constructor(private dialog: MatDialog){}

  newProcurement(){

    this.dialog.open(AddProcurementDialog,{

      width:'700px'

    });

  }

}