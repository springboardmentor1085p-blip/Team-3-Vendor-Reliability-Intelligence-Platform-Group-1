import { Component } from '@angular/core';
import { MatTableModule } from '@angular/material/table';
import { MatIconModule } from '@angular/material/icon';
import { MatButtonModule } from '@angular/material/button';
import { MatChipsModule } from '@angular/material/chips';
import { MatPaginatorModule } from '@angular/material/paginator';
import { DecimalPipe } from '@angular/common';
import { MatMenuModule } from '@angular/material/menu';
import { MatDialog } from '@angular/material/dialog';
import { ViewProcurementDialog } from '../view-procurement-dialog/view-procurement-dialog';
import { EditProcurementDialog } from '../edit-procurement-dialog/edit-procurement-dialog';

export interface Procurement {

  requestId: string;

  item: string;

  vendor: string;

  quantity: number;

  budget: number;

  requiredDate: string;

  status: string;

  priority: string;

}

@Component({
  selector: 'app-procurement-table',
  standalone: true,
  imports: [
    MatTableModule,
    MatIconModule,
    MatButtonModule,
    MatChipsModule,
    MatPaginatorModule,
    DecimalPipe,
    MatMenuModule
  ],
  templateUrl: './procurement-table.html',
  styleUrl: './procurement-table.css'
})
export class ProcurementTable {

  displayedColumns: string[] = [
    'requestId',
    'item',
    'vendor',
    'quantity',
    'budget',
    'requiredDate',
    'status',
    'priority',
    'actions'
  ];

  dataSource: Procurement[] = [

    {
      requestId:'PR-1001',
      item:'Dell Latitude Laptop',
      vendor:'ABC Technologies',
      quantity:20,
      budget:1200000,
      requiredDate:'25 Jul 2026',
      status:'Approved',
      priority:'High'
    },

    {
      requestId:'PR-1002',
      item:'Office Chairs',
      vendor:'Comfort Furniture',
      quantity:40,
      budget:450000,
      requiredDate:'28 Jul 2026',
      status:'Pending',
      priority:'Medium'
    },

    {
      requestId:'PR-1003',
      item:'Network Switch',
      vendor:'Cisco Systems',
      quantity:5,
      budget:600000,
      requiredDate:'02 Aug 2026',
      status:'Rejected',
      priority:'High'
    }

  ];
constructor(private dialog: MatDialog) {}
  viewProcurement(procurement: Procurement): void {
  this.dialog.open(ViewProcurementDialog, {
    width: '600px',
    data: procurement
  });
}

editProcurement(procurement: Procurement): void {

  const dialogRef = this.dialog.open(EditProcurementDialog, {
    width: '550px',
    data: { ...procurement }
  });

  dialogRef.afterClosed().subscribe(result => {

    if (result) {

      const index = this.dataSource.findIndex(
        item => item.requestId === procurement.requestId
      );

      if (index !== -1) {

        this.dataSource[index] = {
          ...this.dataSource[index],
          ...result
        };

        this.dataSource = [...this.dataSource];

      }

    }

  });

}
}

