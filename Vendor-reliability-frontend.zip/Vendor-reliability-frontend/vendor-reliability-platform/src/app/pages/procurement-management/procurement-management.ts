import { Component } from '@angular/core';
import { Navbar } from '../../layouts/navbar/navbar';
import { Sidebar } from '../../layouts/sidebar/sidebar';
import { ProcurementHeader } from './components/procurement-header/procurement-header';
import { ProcurementSummaryCard } from './components/procurement-summary-card/procurement-summary-card';
import { ProcurementToolbar } from './components/procurement-toolbar/procurement-toolbar';
import { ProcurementTable } from './components/procurement-table/procurement-table';

@Component({
  selector: 'app-procurement-management',
  standalone: true,
  imports: [
    Navbar,
    Sidebar,
    ProcurementHeader,
    ProcurementSummaryCard,
    ProcurementToolbar,
    ProcurementTable
  ],
  templateUrl: './procurement-management.html',
  styleUrl: './procurement-management.css'
})
export class ProcurementManagement {

}