import { Component } from '@angular/core';

import { Navbar } from '../../layouts/navbar/navbar';
import { Sidebar } from '../../layouts/sidebar/sidebar';

import { PerformanceSummary }
  from './components/performance-summary/performance-summary';

import { PerformanceCharts }
  from './components/performance-charts/performance-charts';

import { VendorRanking }
  from './components/vendor-ranking/vendor-ranking';
@Component({
  selector: 'app-vendor-performance',

  standalone: true,

  imports: [
    Navbar,
    Sidebar,
    PerformanceSummary,
    PerformanceCharts,
    VendorRanking
  ],

  templateUrl: './vendor-performance.html',
  styleUrl: './vendor-performance.css'
})

export class VendorPerformance {

}