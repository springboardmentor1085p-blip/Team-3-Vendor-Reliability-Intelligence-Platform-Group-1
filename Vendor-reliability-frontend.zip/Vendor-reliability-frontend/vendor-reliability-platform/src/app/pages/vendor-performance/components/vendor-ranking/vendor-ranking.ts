import { Component } from '@angular/core';

import { MatTableModule } from '@angular/material/table';
import { MatCardModule } from '@angular/material/card';
import { MatIconModule } from '@angular/material/icon';
import { MatButtonModule } from '@angular/material/button';
import { MatChipsModule } from '@angular/material/chips';
import { MatTooltipModule } from '@angular/material/tooltip';
import { MatDialog, MatDialogModule } from '@angular/material/dialog';

import {
  VendorReliabilityDialog
} from '../vendor-reliability-dialog/vendor-reliability-dialog';

export interface VendorReliability {

  vendor: string;

  reliabilityScore: number;

  deliveryPerformance: number;

  qualityRating: number;

  riskLevel: string;

  rank: number;
}

@Component({
  selector: 'app-vendor-ranking',

  standalone: true,

  imports: [
    MatTableModule,
    MatCardModule,
    MatIconModule,
    MatButtonModule,
    MatChipsModule,
    MatTooltipModule,
    MatDialogModule
  ],

  templateUrl: './vendor-ranking.html',
  styleUrl: './vendor-ranking.css'
})
export class VendorRanking {

  displayedColumns: string[] = [
    'rank',
    'vendor',
    'reliabilityScore',
    'deliveryPerformance',
    'qualityRating',
    'riskLevel',
    'actions'
  ];


  dataSource: VendorReliability[] = [

    {
      vendor: 'ABC Technologies',
      reliabilityScore: 92,
      deliveryPerformance: 95,
      qualityRating: 4.7,
      riskLevel: 'Low',
      rank: 1
    },

    {
      vendor: 'Cisco Systems',
      reliabilityScore: 87,
      deliveryPerformance: 90,
      qualityRating: 4.5,
      riskLevel: 'Low',
      rank: 2
    },

    {
      vendor: 'Comfort Furniture',
      reliabilityScore: 78,
      deliveryPerformance: 82,
      qualityRating: 4.1,
      riskLevel: 'Medium',
      rank: 3
    },

    {
      vendor: 'Global Logistics',
      reliabilityScore: 72,
      deliveryPerformance: 75,
      qualityRating: 3.9,
      riskLevel: 'High',
      rank: 4
    }

  ];

constructor(private dialog: MatDialog) {}
  viewVendor(vendor: VendorReliability): void {

  this.dialog.open(VendorReliabilityDialog, {

    width: '650px',

    maxWidth: '95vw',

    data: {

      ...vendor,

      communication:
        vendor.vendor === 'ABC Technologies' ? 88 :
        vendor.vendor === 'Cisco Systems' ? 85 :
        vendor.vendor === 'Comfort Furniture' ? 79 : 72,

      compliance:
        vendor.vendor === 'ABC Technologies' ? 96 :
        vendor.vendor === 'Cisco Systems' ? 91 :
        vendor.vendor === 'Comfort Furniture' ? 84 : 76,

      issueResolution:
        vendor.vendor === 'ABC Technologies' ? 87 :
        vendor.vendor === 'Cisco Systems' ? 84 :
        vendor.vendor === 'Comfort Furniture' ? 76 : 69

    }

  });

  }

}