import { Component } from '@angular/core';

import { MatCardModule } from '@angular/material/card';

import { BaseChartDirective } from 'ng2-charts';

import {
  ChartConfiguration,
  ChartData,
} from 'chart.js';

@Component({
  selector: 'app-performance-charts',
  standalone: true,

  imports: [
    MatCardModule,
    BaseChartDirective
  ],

  templateUrl: './performance-charts.html',
  styleUrl: './performance-charts.css'
})
export class PerformanceCharts {

  // -------------------------
  // Performance Breakdown
  // -------------------------

  performanceChartType: 'bar' = 'bar';

  performanceChartData: ChartData<'bar'> = {

    labels: [
      'Delivery',
      'Quality',
      'Communication',
      'Compliance',
      'Issue Resolution'
    ],

    datasets: [
      {
        label: 'Performance Score',

        data: [
          91,
          88,
          84,
          93,
          86
        ]
      }
    ]

  };


  performanceChartOptions: ChartConfiguration<'bar'>['options'] = {

    responsive: true,

    maintainAspectRatio: false,

    indexAxis: 'y',

    scales: {

      x: {
        beginAtZero: true,
        max: 100
      }

    },

    plugins: {

      legend: {
        display: false
      }

    }

  };


  // -------------------------
  // Performance Trend
  // -------------------------

  trendChartType: 'line' = 'line';

  trendChartData: ChartData<'line'> = {

    labels: [
      'Jan',
      'Feb',
      'Mar',
      'Apr',
      'May',
      'Jun'
    ],

    datasets: [
      {
        label: 'Reliability Score',

        data: [
          78,
          80,
          82,
          81,
          84,
          86
        ],

        tension: 0.4,

        fill: false
      }
    ]

  };


  trendChartOptions: ChartConfiguration<'line'>['options'] = {

    responsive: true,

    maintainAspectRatio: false,

    scales: {

      y: {
        beginAtZero: false,
        min: 60,
        max: 100
      }

    }

  };

}