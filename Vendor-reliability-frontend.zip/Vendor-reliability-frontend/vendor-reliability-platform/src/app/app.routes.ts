import { Routes } from '@angular/router';
import { Login } from './pages/login/login';
import { Dashboard } from './pages/dashboard/dashboard';
import { VendorManagement } from './pages/vendor-management/vendor-management';
import {VendorPerformance} from './pages/vendor-performance/vendor-performance';
import { ProcurementManagement } from './pages/procurement-management/procurement-management';
import { PurchaseOrders } from './pages/purchase-orders/purchase-orders';
import { ContractManagement } from './pages/contract-management/contract-management';
import { Communication } from './pages/communication/communication';
import { Analytics } from './pages/analytics/analytics';
import { Reports } from './pages/reports/reports';
import { Settings }from './pages/settings/settings';
import { authGuard } from './guards/auth-guard';
import { Register } from './pages/auth/register/register';

import { ForgotPassword } from './pages/auth/forgot-password/forgot-password';

export const routes: Routes = [

  {
  path: '',
  redirectTo: 'login',
  pathMatch: 'full'
},

    {
    path: 'login',
    component: Login
  },

  {
    path: 'register',
    component: Register
  },
  
  {
  path: 'forgot-password',
  component: ForgotPassword
},

{
  path:'dashboard',
  component:Dashboard,
},
  {
  path:'vendor-management',
  component:VendorManagement,
  
},
{
  path:'vendor-performance',
  component:VendorPerformance,
},

{
  path:'procurement-management',
  component:ProcurementManagement,
  
},
{
  path:'purchase-orders',
  component:PurchaseOrders,
},
{
  path:'contract-management',
  component:ContractManagement,
},
{
  path:'analytics',
  component:Analytics,
},
{
  path:'communication',
  component:Communication,
},
{
  path:'reports',
  component:Reports,
},
{
  path:'settings',
  component:Settings,
  
},
{
  path: '**',
  redirectTo: 'login'
}
];