import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';

import { MatToolbarModule } from '@angular/material/toolbar';
import { MatIconModule } from '@angular/material/icon';
import { MatButtonModule } from '@angular/material/button';
import { MatMenuModule } from '@angular/material/menu';

interface Notification {
  id: number;
  title: string;
  message: string;
  time: string;
  read: boolean;
  icon: string;
}

@Component({
  selector: 'app-navbar',

  standalone: true,

  imports: [
    CommonModule,
    MatToolbarModule,
    MatIconModule,
    MatButtonModule,
    MatMenuModule
  ],

  templateUrl: './navbar.html',
  styleUrl: './navbar.css'
})

export class Navbar {

  notifications: Notification[] = [

    {
      id: 1,
      title: 'Purchase Order Approved',
      message: 'PO-1003 has been approved.',
      time: '10 minutes ago',
      read: false,
      icon: 'shopping_cart'
    },

    {
      id: 2,
      title: 'High Risk Vendor',
      message: 'ABC Technologies has been marked as high risk.',
      time: '1 hour ago',
      read: false,
      icon: 'warning_amber'
    },

    {
      id: 3,
      title: 'Contract Expiring Soon',
      message: 'Contract CT-1004 expires in 7 days.',
      time: '2 hours ago',
      read: true,
      icon: 'schedule'
    }

  ];


  get unreadCount(): number {

    return this.notifications.filter(
      notification => !notification.read
    ).length;

  }


  markAsRead(notification: Notification): void {

    notification.read = true;

  }


  markAllAsRead(): void {

    this.notifications.forEach(
      notification => notification.read = true
    );

  }

}