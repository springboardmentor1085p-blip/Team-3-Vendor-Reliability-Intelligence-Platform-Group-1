# Core application infrastructure (security, exceptions, middleware)
