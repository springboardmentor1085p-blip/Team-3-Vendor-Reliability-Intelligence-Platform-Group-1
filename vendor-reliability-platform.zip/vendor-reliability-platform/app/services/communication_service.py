"""
Service layer for Messages / Communication operations.
"""

from typing import Sequence
from uuid import UUID

from sqlalchemy.ext.asyncio import AsyncSession

from app.core.exceptions import EntityNotFoundError
from app.models.communication import Message
from app.repositories.communication_repository import (
    CommunicationRepository,
    communication_repository,
)
from app.schemas.communication import MessageCreate


class CommunicationService:
    def __init__(self, repo: CommunicationRepository | None = None) -> None:
        self.repo = repo or communication_repository

    async def get_message(self, db: AsyncSession, message_id: UUID) -> Message:
        msg = await self.repo.get_by_id(db, message_id)
        if not msg:
            raise EntityNotFoundError(f"Message with ID {message_id} not found.")
        return msg

    async def get_all_messages(
        self,
        db: AsyncSession,
        skip: int = 0,
        limit: int = 100,
    ) -> Sequence[Message]:
        return await self.repo.get_all(db, skip=skip, limit=limit)

    async def send_message(
        self,
        db: AsyncSession,
        sender_id: UUID,
        obj_in: MessageCreate,
    ) -> Message:
        return await self.repo.create(db, sender_id, obj_in)


communication_service = CommunicationService()
