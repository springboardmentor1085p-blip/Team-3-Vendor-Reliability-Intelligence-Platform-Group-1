# Vendor Reliability Intelligence Platform

Production-ready FastAPI backend following clean architecture principles.
